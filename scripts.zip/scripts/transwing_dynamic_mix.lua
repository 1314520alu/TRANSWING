-- Transwing fold-angle estimator, dynamic mix prototype, and transition guard.
-- SITL-first: motor mix outputs stay isolated unless TW_LOG_ONLY=0.

local SCRIPT_NAME = "TW-DYNMIX"
local MAV_SEVERITY_INFO = 6
local MAV_SEVERITY_WARNING = 4

local TABLE_KEY = 91
assert(param:add_table(TABLE_KEY, "TW_", 33), "could not add TW_ parameter table")

assert(param:add_param(TABLE_KEY, 1, "ENABLE", 1), "could not add TW_ENABLE")
assert(param:add_param(TABLE_KEY, 2, "LOG_ONLY", 1), "could not add TW_LOG_ONLY")
assert(param:add_param(TABLE_KEY, 3, "FOLD_CH", 10), "could not add TW_FOLD_CH")
assert(param:add_param(TABLE_KEY, 4, "PWM_FW", 2000), "could not add TW_PWM_FW")
assert(param:add_param(TABLE_KEY, 5, "PWM_Q", 1000), "could not add TW_PWM_Q")
assert(param:add_param(TABLE_KEY, 6, "RATE_UP", 4.5), "could not add TW_RATE_UP")
assert(param:add_param(TABLE_KEY, 7, "RATE_DN", 4.5), "could not add TW_RATE_DN")
assert(param:add_param(TABLE_KEY, 8, "TIMEOUT", 25), "could not add TW_TIMEOUT")
assert(param:add_param(TABLE_KEY, 9, "OUT_GAIN", 0.2), "could not add TW_OUT_GAIN")
assert(param:add_param(TABLE_KEY, 10, "THR", 0), "could not add TW_THR")
assert(param:add_param(TABLE_KEY, 11, "ROLL", 0), "could not add TW_ROLL")
assert(param:add_param(TABLE_KEY, 12, "PITCH", 0), "could not add TW_PITCH")
assert(param:add_param(TABLE_KEY, 13, "YAW", 0), "could not add TW_YAW")
assert(param:add_param(TABLE_KEY, 14, "GUARD", 1), "could not add TW_GUARD")
assert(param:add_param(TABLE_KEY, 15, "SAFE_MIN", 55), "could not add TW_SAFE_MIN")
assert(param:add_param(TABLE_KEY, 16, "BLEND_AS", 11), "could not add TW_BLEND_AS")
assert(param:add_param(TABLE_KEY, 17, "FW_AS", 15), "could not add TW_FW_AS")
assert(param:add_param(TABLE_KEY, 18, "ATT_DANG", 55), "could not add TW_ATT_DANG")
assert(param:add_param(TABLE_KEY, 19, "DESC_DANG", -8), "could not add TW_DESC_DANG")
assert(param:add_param(TABLE_KEY, 20, "SAT_PWM", 1980), "could not add TW_SAT_PWM")
assert(param:add_param(TABLE_KEY, 21, "ACCEL_MIN", 55), "could not add TW_ACCEL_MIN")
assert(param:add_param(TABLE_KEY, 22, "ATT_ABORT", 42), "could not add TW_ATT_ABORT")
assert(param:add_param(TABLE_KEY, 23, "MIX_MODE", 0), "could not add TW_MIX_MODE")
assert(param:add_param(TABLE_KEY, 24, "INPUT_SRC", 1), "could not add TW_INPUT_SRC")
assert(param:add_param(TABLE_KEY, 25, "GUARD_FBWA", 1), "could not add TW_GUARD_FBWA")
assert(param:add_param(TABLE_KEY, 26, "MIX_BLEND", 0), "could not add TW_MIX_BLEND")
assert(param:add_param(TABLE_KEY, 27, "GUARD_MS", 1000), "could not add TW_GUARD_MS")
assert(param:add_param(TABLE_KEY, 28, "BLEND_MIN", 30), "could not add TW_BLEND_MIN")
assert(param:add_param(TABLE_KEY, 29, "ASST_EN", 1), "could not add TW_ASST_EN")
assert(param:add_param(TABLE_KEY, 30, "FB_EN", 1), "could not add TW_FB_EN")
assert(param:add_param(TABLE_KEY, 31, "FB_REQ", 1), "could not add TW_FB_REQ")
assert(param:add_param(TABLE_KEY, 32, "FB_STALE", 1000), "could not add TW_FB_STALE")
assert(param:add_param(TABLE_KEY, 33, "THETA_MAX", 90), "could not add TW_THETA_MAX")

local P = {}
for _, name in ipairs({
  "ENABLE", "LOG_ONLY", "FOLD_CH", "PWM_FW", "PWM_Q", "RATE_UP", "RATE_DN",
  "TIMEOUT", "OUT_GAIN", "THR", "ROLL", "PITCH", "YAW", "GUARD", "SAFE_MIN",
  "BLEND_AS", "FW_AS", "ATT_DANG", "DESC_DANG", "SAT_PWM", "ACCEL_MIN", "ATT_ABORT",
  "MIX_MODE", "INPUT_SRC", "GUARD_FBWA", "MIX_BLEND", "GUARD_MS", "BLEND_MIN", "ASST_EN",
  "FB_EN", "FB_REQ", "FB_STALE", "THETA_MAX"
}) do
  P[name] = Parameter("TW_" .. name)
end

-- Packed to stay under Lua main-chunk 100-local limit.
local FB = {
  msg_id = 251,
  msg_map = { [251] = "NAMED_VALUE_FLOAT" },
  msgs = nil,
  pct = 0,
  cnt = 0,
  flt = 0,
  pwm = 0,
  hld = 0,
  have_pct = false,
  last_rx_ms = nil,
  rx_ready = false,
  rx_attempted = false,
  warned_rx = false,
  enabled_prev = false,
  drain_rx = false,
  warned_req = false,
  last_gcs_ms = nil,
}

local function ensure_mavlink_rx()
  if FB.rx_ready then return true end
  if FB.rx_attempted then return false end
  FB.rx_attempted = true
  local ok, err = pcall(function()
    FB.msgs = require("MAVLink/mavlink_msgs")
    local discovered_id = FB.msgs.get_msgid("NAMED_VALUE_FLOAT")
    if discovered_id ~= FB.msg_id then
      error("unexpected NAMED_VALUE_FLOAT msgid")
    end
    mavlink:init(25, 1)
    mavlink:register_rx_msgid(FB.msg_id)
  end)
  FB.rx_ready = ok
  if not ok and not FB.warned_rx then
    local why = tostring(err or "?")
    -- Prefer the human part after the last colon/slash for GCS 50-char limit.
    local short = why:match("([^:/\\]+)$") or why
    if #short > 42 then short = short:sub(1, 42) end
    gcs:send_text(MAV_SEVERITY_WARNING, SCRIPT_NAME .. ": FB fail " .. short)
    FB.warned_rx = true
  end
  return ok
end

local function nvf_name(raw)
  if raw == nil then return "" end
  return tostring(raw):match("^[^%z]*") or ""
end

local function poll_fold_mavlink(now_ms)
  local fb_enabled = P.FB_EN:get() >= 0.5
  if fb_enabled and not FB.enabled_prev then
    FB.have_pct = false
    FB.last_rx_ms = nil
    FB.drain_rx = true
  end
  FB.enabled_prev = fb_enabled

  if not ensure_mavlink_rx() then return end
  local drain_only = FB.drain_rx
  local msg = mavlink:receive_chan()
  while msg do
    if not drain_only then
      local ok, decoded = pcall(FB.msgs.decode, msg, FB.msg_map)
      if fb_enabled and ok and decoded then
        local name = nvf_name(decoded.name)
        local value = decoded.value
        if name == "fold_pct" then
          FB.pct = value
          FB.have_pct = true
          FB.last_rx_ms = now_ms
        elseif name == "fold_cnt" then
          FB.cnt = value
          FB.last_rx_ms = now_ms
        elseif name == "fold_flt" then
          FB.flt = value
          FB.last_rx_ms = now_ms
        elseif name == "fold_pwm" then
          FB.pwm = value
          FB.last_rx_ms = now_ms
        elseif name == "fold_hld" then
          FB.hld = value
          FB.last_rx_ms = now_ms
        end
      end
    end
    msg = mavlink:receive_chan()
  end
  if drain_only then
    FB.drain_rx = false
  end
end

local function compute_fb_ok(now_ms)
  if P.FB_EN:get() < 0.5 then return false end
  if not FB.have_pct then return false end
  if FB.last_rx_ms == nil then return false end
  if (now_ms - FB.last_rx_ms) > P.FB_STALE:get() then return false end
  if FB.flt >= 0.5 then return false end
  if FB.hld >= 0.5 then return false end
  return true
end

-- Re-publish fold_* as FC-origin NAMED_VALUE_FLOAT so Mission Planner Quick/HUD can show them
-- (board frames use compid 191 and are ignored by MP Quick).
local function publish_fold_gcs(now_ms, fb_ok_now)
  if P.FB_EN:get() < 0.5 then return end
  if FB.last_gcs_ms ~= nil and (now_ms - FB.last_gcs_ms) < 200 then return end
  FB.last_gcs_ms = now_ms
  gcs:send_named_float("fold_pct", FB.pct)
  gcs:send_named_float("fold_cnt", FB.cnt)
  gcs:send_named_float("fold_flt", FB.flt)
  gcs:send_named_float("fold_pwm", FB.pwm)
  gcs:send_named_float("fold_hld", FB.hld)
  gcs:send_named_float("fold_ok", fb_ok_now and 1 or 0)
  gcs:send_named_float("fold_deg", FB.pct * 0.01 * P.THETA_MAX:get())
end

local FACTOR_TABLE = {
  {
    theta = 0,
    motors = {
      { name = "M1", throttle = 0, roll = 0.000000, pitch = -0.750000, yaw_force = -0.326531, yaw_drag = 1 },
      { name = "M2", throttle = 0, roll = 0.000000, pitch = -1.000000, yaw_force = 1.000000, yaw_drag = 1 },
      { name = "M3", throttle = 0, roll = 0.000000, pitch = -0.750000, yaw_force = 0.326531, yaw_drag = -1 },
      { name = "M4", throttle = 0, roll = 0.000000, pitch = -1.000000, yaw_force = -1.000000, yaw_drag = -1 },
    },
  },
  {
    theta = 15,
    motors = {
      { name = "M1", throttle = 1, roll = -0.353266, pitch = -0.691231, yaw_force = -0.353266, yaw_drag = 1 },
      { name = "M2", throttle = 1, roll = 1.000000, pitch = -1.000000, yaw_force = 1.000000, yaw_drag = 1 },
      { name = "M3", throttle = 1, roll = 0.353266, pitch = -0.691231, yaw_force = 0.353266, yaw_drag = -1 },
      { name = "M4", throttle = 1, roll = -1.000000, pitch = -1.000000, yaw_force = -1.000000, yaw_drag = -1 },
    },
  },
  {
    theta = 30,
    motors = {
      { name = "M1", throttle = 1, roll = -0.430762, pitch = 1.000000, yaw_force = -0.430762, yaw_drag = 1 },
      { name = "M2", throttle = 1, roll = 1.000000, pitch = 0.213987, yaw_force = 1.000000, yaw_drag = 1 },
      { name = "M3", throttle = 1, roll = 0.430762, pitch = 1.000000, yaw_force = 0.430762, yaw_drag = -1 },
      { name = "M4", throttle = 1, roll = -1.000000, pitch = 0.213987, yaw_force = -1.000000, yaw_drag = -1 },
    },
  },
  {
    theta = 45,
    motors = {
      { name = "M1", throttle = 1, roll = -0.562500, pitch = 1.000000, yaw_force = -0.562500, yaw_drag = 1 },
      { name = "M2", throttle = 1, roll = 1.000000, pitch = -0.100000, yaw_force = 1.000000, yaw_drag = 1 },
      { name = "M3", throttle = 1, roll = 0.562500, pitch = 1.000000, yaw_force = 0.562500, yaw_drag = -1 },
      { name = "M4", throttle = 1, roll = -1.000000, pitch = -0.100000, yaw_force = -1.000000, yaw_drag = -1 },
    },
  },
  {
    theta = 60,
    motors = {
      { name = "M1", throttle = 1, roll = -0.749689, pitch = 1.000000, yaw_force = -0.749689, yaw_drag = 1 },
      { name = "M2", throttle = 1, roll = 1.000000, pitch = -0.536819, yaw_force = 1.000000, yaw_drag = 1 },
      { name = "M3", throttle = 1, roll = 0.749689, pitch = 1.000000, yaw_force = 0.749689, yaw_drag = -1 },
      { name = "M4", throttle = 1, roll = -1.000000, pitch = -0.536819, yaw_force = -1.000000, yaw_drag = -1 },
    },
  },
  {
    theta = 75,
    motors = {
      { name = "M1", throttle = 1, roll = -0.957651, pitch = 1.000000, yaw_force = -0.957651, yaw_drag = 1 },
      { name = "M2", throttle = 1, roll = 1.000000, pitch = -0.869630, yaw_force = 1.000000, yaw_drag = 1 },
      { name = "M3", throttle = 1, roll = 0.957651, pitch = 1.000000, yaw_force = 0.957651, yaw_drag = -1 },
      { name = "M4", throttle = 1, roll = -1.000000, pitch = -0.869630, yaw_force = -1.000000, yaw_drag = -1 },
    },
  },
  {
    theta = 90,
    motors = {
      { name = "M1", throttle = 1, roll = -1.000000, pitch = 1.000000, yaw_force = 0.000000, yaw_drag = 1 },
      { name = "M2", throttle = 1, roll = 0.938776, pitch = -1.000000, yaw_force = 0.000000, yaw_drag = 1 },
      { name = "M3", throttle = 1, roll = 1.000000, pitch = 1.000000, yaw_force = 0.000000, yaw_drag = -1 },
      { name = "M4", throttle = 1, roll = -0.938776, pitch = -1.000000, yaw_force = 0.000000, yaw_drag = -1 },
    },
  },
}

local PHASE = { HOVER = 0, ACCEL = 1, BLEND = 2, FIXED_WING = 3 }
local RISK = { OK = 0, WARN = 1, DANGER = 2 }
local ACTION = { ALLOW = 0, HOLD_THETA = 1, ABORT_TO_Q = 2 }
local MIX_MODE_OBSERVE = 0
local MIX_MODE_MIRROR = 1
local MIX_MODE_CONTROL = 2
local INPUT_SRC_PARAM = 0
local INPUT_SRC_RC = 1
local MODE_FBWA = 5
local MODE_FBWB = 6
local MODE_QSTABILIZE = 17
local K_TILT_MOTORS_FRONT = 41

local ST = {
  theta_est = 0,
  theta_ol = 0,
  theta_cmd = 0,
  theta_target = 0,
  theta_ap_target = nil,
  fold_cmd_init = false,
  last_fold_cmd_pwm = nil,
  last_ms = millis():tofloat(),
  boot_ms = nil,
  target_changed_ms = nil,
  last_target = nil,
  warned_timeout = false,
  warned_guard = false,
  last_guard_reason = nil,
  announced = false,
  last_ann_mix = nil,
  last_ann_log = nil,
  climb_filt = 0,
  climb_filt_init = false,
  descent_exceed_start_ms = nil,
  motors_registered = false,
  motors_dynamic_active = false,
  warned_no_motors_dynamic = false,
}
ST.boot_ms = ST.last_ms
ST.target_changed_ms = ST.last_ms

-- Motor test order A,C,D,B for Transwing M1-M4 on Quad X dynamic matrix.
local MOTOR_TEST_ORDER = { 1, 3, 4, 2 }

local CLIMB_FILTER_TAU_S = 0.5
local DESC_SUSTAIN_S = 0.4
local DESC_SEVERE_SCALE = 1.5
local BOOT_GUARD_GRACE_S = 15
local BOOT_GUARD_MAX_AS = 3
local FOLD_OVERRIDE_MS = 400

local function clamp(value, min_value, max_value)
  if value < min_value then return min_value end
  if value > max_value then return max_value end
  return value
end

local function fold_pct_to_theta(pct)
  local p = clamp(pct, 0, 100)
  return (p / 100.0) * P.THETA_MAX:get()
end

local function lerp(a, b, ratio)
  return a + (b - a) * ratio
end

local function pwm_to_theta_target(pwm, pwm_fw, pwm_q)
  if pwm == nil or pwm_fw == pwm_q then return ST.theta_target end
  local ratio = clamp((pwm - pwm_fw) / (pwm_q - pwm_fw), 0, 1)
  return ratio * 90
end

local function theta_to_pwm(theta, pwm_fw, pwm_q)
  return math.floor(pwm_fw + clamp(theta, 0, 90) / 90 * (pwm_q - pwm_fw) + 0.5)
end

local function step_theta_estimate(theta, target, dt, rate_up, rate_dn)
  local delta = target - theta
  if delta == 0 or dt <= 0 then return theta end
  local rate = delta > 0 and rate_up or rate_dn
  local max_step = math.abs(rate * dt)
  if math.abs(delta) <= max_step then return target end
  return theta + (delta > 0 and max_step or -max_step)
end

local function infer_ap_fold_target(flight_mode, airspeed)
  if flight_mode >= MODE_QSTABILIZE and flight_mode <= 23 then return 90 end
  -- Fixed-wing pilot modes: AP always commands forward fold regardless of airspeed.
  if flight_mode == MODE_FBWA or flight_mode == MODE_FBWB then return 0 end
  if airspeed >= P.FW_AS:get() then return 0 end
  return nil
end

local function read_ap_fold_pwm(fold_chan)
  local pwm = SRV_Channels:get_output_pwm(K_TILT_MOTORS_FRONT)
  if pwm ~= nil and pwm ~= false and pwm > 0 then return pwm end
  return SRV_Channels:get_output_pwm_chan(fold_chan)
end

local function update_ap_fold_target(raw_pwm, pwm_fw, pwm_q, flight_mode, airspeed, theta_cmd, prev_target, dt, rate_up, rate_dn)
  local inferred = infer_ap_fold_target(flight_mode, airspeed)
  if inferred ~= nil then return inferred end

  local from_pwm = pwm_to_theta_target(raw_pwm, pwm_fw, pwm_q)
  local max_step = math.max(rate_up, rate_dn) * math.max(dt, 0.05) * 2 + 2

  if prev_target == nil then return from_pwm end

  if math.abs(from_pwm - theta_cmd) <= max_step + 1 then
    return from_pwm
  end
  if math.abs(from_pwm - prev_target) > max_step + 1 then
    return from_pwm
  end
  return prev_target
end

local function fold_slew_active(mix_mode)
  return mix_mode == MIX_MODE_CONTROL
end

local function apply_fold_servo_output(fold_chan, theta_cmd, pwm_fw, pwm_q, timeout_ms)
  local cmd_pwm = theta_to_pwm(theta_cmd, pwm_fw, pwm_q)
  SRV_Channels:set_output_pwm_chan_timeout(fold_chan, cmd_pwm, timeout_ms)
  ST.last_fold_cmd_pwm = cmd_pwm
  return cmd_pwm
end

local function interpolate_factors(theta)
  if theta <= FACTOR_TABLE[1].theta then return FACTOR_TABLE[1].motors end
  if theta >= FACTOR_TABLE[#FACTOR_TABLE].theta then return FACTOR_TABLE[#FACTOR_TABLE].motors end

  local lower = FACTOR_TABLE[1]
  local upper = FACTOR_TABLE[#FACTOR_TABLE]
  for i = 2, #FACTOR_TABLE do
    if FACTOR_TABLE[i].theta >= theta then
      lower = FACTOR_TABLE[i - 1]
      upper = FACTOR_TABLE[i]
      break
    end
  end

  local ratio = (theta - lower.theta) / (upper.theta - lower.theta)
  local out = {}
  for i = 1, 4 do
    local lo = lower.motors[i]
    local hi = upper.motors[i]
    out[i] = {
      name = lo.name,
      throttle = lerp(lo.throttle, hi.throttle, ratio),
      roll = lerp(lo.roll, hi.roll, ratio),
      pitch = lerp(lo.pitch, hi.pitch, ratio),
      yaw_force = lerp(lo.yaw_force, hi.yaw_force, ratio),
      yaw_drag = lerp(lo.yaw_drag, hi.yaw_drag, ratio),
    }
  end
  return out
end

local function mix_to_pwm(factor, throttle, roll, pitch, yaw, gain)
  local min_pwm = 1100
  local hover_pwm = 1500
  local max_pwm = 1900
  local normalized = throttle * factor.throttle +
    gain * (roll * factor.roll + pitch * factor.pitch + yaw * (factor.yaw_force + factor.yaw_drag))
  return math.floor(clamp(hover_pwm + normalized * (max_pwm - hover_pwm), min_pwm, max_pwm) + 0.5)
end

local function phase_for_theta(theta)
  local blend_min = P.BLEND_MIN:get()
  local accel_min = P.ACCEL_MIN:get()
  if theta > 75 then return PHASE.HOVER end
  if theta >= accel_min then return PHASE.ACCEL end
  if theta >= blend_min then return PHASE.BLEND end
  return PHASE.FIXED_WING
end

local function read_airspeed()
  if ahrs == nil then return 0 end
  local ok, value = pcall(function() return ahrs:airspeed_estimate() end)
  if ok and value ~= nil then return value end
  return 0
end

local function get_param_value(name, default)
  local ok, param_obj = pcall(function() return Parameter(name) end)
  if ok and param_obj ~= nil then
    local ok_get, value = pcall(function() return param_obj:get() end)
    if ok_get and value ~= nil then return value end
  end
  return default
end

local function is_vtol_flight_mode(mode)
  return mode >= MODE_QSTABILIZE and mode <= 23
end

local function read_assist_active(airspeed, flight_mode)
  if quadplane ~= nil then
    local ok, active = pcall(function() return quadplane:in_assisted_flight() end)
    if ok and active ~= nil then
      return active == true
    end
  end
  -- Fallback only when quadplane binding is missing.
  local assist_speed = get_param_value("Q_ASSIST_SPEED", 0)
  if assist_speed <= 0 then return false end
  if flight_mode < 0 or is_vtol_flight_mode(flight_mode) then return false end
  local min_as = math.max(3, P.BLEND_AS:get())
  return airspeed >= min_as and airspeed < assist_speed
end

local function apply_assist_link(assist_active, target, allowed, action, risk, airspeed)
  if not assist_active or P.ASST_EN:get() < 0.5 then
    return allowed, action, risk
  end
  if action == ACTION.ABORT_TO_Q then return allowed, action, risk end
  local hold = P.SAFE_MIN:get()
  -- Above blend airspeed, allow fold to continue past SAFE_MIN during FW transition.
  if target < hold and airspeed >= P.BLEND_AS:get() then
    return allowed, action, risk
  end
  if target >= hold then return allowed, action, risk end
  if allowed < hold then
    allowed = hold
    action = ACTION.HOLD_THETA
    if risk == RISK.OK then risk = RISK.WARN end
  end
  return allowed, action, risk
end

local function mix_theta_for_assist(mix_theta, assist_active, airspeed)
  if not assist_active or P.ASST_EN:get() < 0.5 then return mix_theta end
  if airspeed >= P.BLEND_AS:get() and mix_theta <= P.SAFE_MIN:get() + 1 then
    return mix_theta
  end
  return math.max(mix_theta, P.SAFE_MIN:get())
end

local function read_attitude_deg()
  if ahrs == nil then return 0, 0 end
  -- Prefer *_deg when present; else *_rad (old get_roll/get_pitch are deprecated).
  local ok_roll, roll = pcall(function() return ahrs:get_roll_deg() end)
  local ok_pitch, pitch = pcall(function() return ahrs:get_pitch_deg() end)
  if ok_roll and roll ~= nil and ok_pitch and pitch ~= nil then
    return roll, pitch
  end
  ok_roll, roll = pcall(function() return ahrs:get_roll_rad() end)
  ok_pitch, pitch = pcall(function() return ahrs:get_pitch_rad() end)
  if not ok_roll or roll == nil then roll = 0 end
  if not ok_pitch or pitch == nil then pitch = 0 end
  return math.deg(roll), math.deg(pitch)
end

local function norm_rc_pwm(pwm, min_pwm, max_pwm)
  if pwm == nil or pwm < 1 or max_pwm == min_pwm then return nil end
  return clamp((pwm - min_pwm) / (max_pwm - min_pwm), 0, 1)
end

local function norm_rc_stick(pwm, center, half_span)
  if pwm == nil or pwm < 1 or half_span <= 0 then return nil end
  return clamp((pwm - center) / half_span, -1, 1)
end

local function read_control_inputs()
  local throttle = clamp(P.THR:get(), 0, 1)
  local roll = clamp(P.ROLL:get(), -1, 1)
  local pitch = clamp(P.PITCH:get(), -1, 1)
  local yaw = clamp(P.YAW:get(), -1, 1)

  if math.floor(P.INPUT_SRC:get() + 0.5) ~= INPUT_SRC_RC then
    return throttle, roll, pitch, yaw
  end

  if rc == nil then return throttle, roll, pitch, yaw end

  local pwm_min = get_param_value("Q_M_PWM_MIN", 1000)
  local pwm_max = get_param_value("Q_M_PWM_MAX", 2000)
  local stick_half = math.max(get_param_value("RC1_DZ", 0) + 500, 100)

  local ok_thr, thr_pwm = pcall(function() return rc:get_pwm(3) end)
  if ok_thr then
    local normalized = norm_rc_pwm(thr_pwm, pwm_min, pwm_max)
    if normalized ~= nil then throttle = normalized end
  end

  local stick_channels = {
    { chan = 1, setter = function(v) roll = v end },
    { chan = 2, setter = function(v) pitch = v end },
    { chan = 4, setter = function(v) yaw = v end },
  }
  for _, mapping in ipairs(stick_channels) do
    local ok_pwm, stick_pwm = pcall(function() return rc:get_pwm(mapping.chan) end)
    if ok_pwm then
      local center = get_param_value("RC" .. mapping.chan .. "_TRIM", 1500)
      local normalized = norm_rc_stick(stick_pwm, center, stick_half)
      if normalized ~= nil then mapping.setter(normalized) end
    end
  end

  return throttle, roll, pitch, yaw
end

local function get_flight_mode()
  if vehicle == nil then return -1 end
  local ok, mode = pcall(function() return vehicle:get_mode() end)
  if ok and mode ~= nil then return mode end
  return -1
end

local function mode_allows_lua_mix(mode)
  if mode == MODE_FBWA then return false end
  if mode == MODE_FBWB then return true end
  if mode >= MODE_QSTABILIZE and mode <= 23 then return true end
  return false
end

local function can_takeover_motors(mix_mode, action, flight_mode, target, estimate, fb_ok_flag)
  if P.LOG_ONLY:get() >= 0.5 then return false end
  if mix_mode ~= MIX_MODE_CONTROL then return false end
  if P.FB_REQ:get() >= 0.5 and not fb_ok_flag then return false end
  if action ~= ACTION.ALLOW then return false end
  if not mode_allows_lua_mix(flight_mode) then return false end
  if math.abs(target - estimate) >= 3 then return false end
  return true
end

local function register_motors_dynamic()
  if ST.motors_registered or Motors_dynamic == nil then
    return ST.motors_registered
  end
  for i = 0, 3 do
    Motors_dynamic:add_motor(i, MOTOR_TEST_ORDER[i + 1])
  end
  ST.motors_registered = true
  return true
end

local function apply_dynamic_motor_mix(factors)
  if Motors_dynamic == nil then
    return false
  end
  if not register_motors_dynamic() then
    return false
  end

  local factor_table = motor_factor_table()
  for i = 1, 4 do
    local f = factors[i]
    local idx = i - 1
    factor_table:roll(idx, f.roll)
    factor_table:pitch(idx, f.pitch)
    factor_table:yaw(idx, f.yaw_force + f.yaw_drag)
    factor_table:throttle(idx, f.throttle)
  end

  Motors_dynamic:load_factors(factor_table)
  if not Motors_dynamic:init(4) then
    return false
  end

  if motors ~= nil then
    pcall(function() motors:set_frame_string("TW DynMix") end)
  end
  return true
end

local function warn_missing_motors_dynamic()
  if ST.warned_no_motors_dynamic then return end
  gcs:send_text(MAV_SEVERITY_WARNING,
    SCRIPT_NAME .. ": set Q_FRAME_CLASS=17 for Lua motor mix (Motors_dynamic)")
  ST.warned_no_motors_dynamic = true
end

local function read_climb_rate()
  if ahrs == nil then return 0 end
  local ok, vel = pcall(function() return ahrs:get_velocity_NED() end)
  if ok and vel ~= nil then
    local ok_z, z = pcall(function() return vel:z() end)
    if ok_z and z ~= nil then return -z end
  end
  return 0
end

local function is_saturated(pwm, sat_pwm)
  -- Only treat upper PWM clamp as saturation. A lower bound of 1100 falsely
  -- flags Q_M_PWM_MIN (~1000) idle outputs during transition.
  local max_pwm = 0
  for i = 1, #pwm do
    if pwm[i] > max_pwm then max_pwm = pwm[i] end
    if pwm[i] >= sat_pwm then return 1 end
  end
  -- Differential floor: one motor at ESC minimum while another is near max.
  for i = 1, #pwm do
    if pwm[i] <= 1050 and max_pwm >= (sat_pwm - 50) then return 1 end
  end
  return 0
end

local function read_motor_pwm_fallback(fallback)
  local actual = {}
  local have_actual = false
  for i = 1, 4 do
    local value = SRV_Channels:get_output_pwm_chan(i - 1)
    if value ~= nil and value > 0 then
      actual[i] = value
      have_actual = true
    else
      actual[i] = fallback[i]
    end
  end
  if have_actual then return actual end
  return fallback
end

local function airspeed_guard_active(airspeed)
  return airspeed >= BOOT_GUARD_MAX_AS
end

local function guard_reason_key(reason)
  if reason == nil or reason == "" or reason == "nominal" then
    return reason or "nominal"
  end
  return reason:gsub("%d+%.%d+", "X"):gsub("%d+", "N")
end

local function append_reason(parts, text)
  if text ~= nil and text ~= "" then
    parts[#parts + 1] = text
  end
end

local function build_guard_reason(target, airspeed, roll_deg, pitch_deg, climb_rate, saturation, descent_sustained, assist_active, as_guard)
  local reasons = {}
  local accel_min = P.ACCEL_MIN:get()
  local blend_min = P.BLEND_MIN:get()
  local assist_hold = P.SAFE_MIN:get()

  if assist_active and P.ASST_EN:get() > 0.5 and target < assist_hold then
    append_reason(reasons, string.format("assist active hold %.0f", assist_hold))
  end

  if as_guard and target >= accel_min and target < 90 and airspeed < P.BLEND_AS:get() then
    append_reason(reasons, string.format("accel airspeed %.1f<%.0f", airspeed, P.BLEND_AS:get()))
  end
  if as_guard and target < accel_min and target >= blend_min and airspeed < P.BLEND_AS:get() then
    append_reason(reasons, string.format("blend airspeed %.1f<%.0f", airspeed, P.BLEND_AS:get()))
  end
  if as_guard and target < blend_min and airspeed < P.FW_AS:get() then
    append_reason(reasons, string.format("fixed-wing airspeed %.1f<%.0f", airspeed, P.FW_AS:get()))
  end
  if math.abs(roll_deg) > P.ATT_ABORT:get() or math.abs(pitch_deg) > P.ATT_ABORT:get() then
    append_reason(reasons, string.format("attitude roll=%.1f pitch=%.1f > abort %.1f",
      math.abs(roll_deg), math.abs(pitch_deg), P.ATT_ABORT:get()))
  elseif math.abs(roll_deg) > P.ATT_DANG:get() or math.abs(pitch_deg) > P.ATT_DANG:get() then
    append_reason(reasons, string.format("attitude roll=%.1f pitch=%.1f > danger %.1f",
      math.abs(roll_deg), math.abs(pitch_deg), P.ATT_DANG:get()))
  end
  if climb_rate < P.DESC_DANG:get() then
    append_reason(reasons, string.format("descent %.1f<%.1f", climb_rate, P.DESC_DANG:get()))
  end
  if descent_sustained and climb_rate < P.DESC_DANG:get() then
    append_reason(reasons, string.format("descent sustained %.1fs", DESC_SUSTAIN_S))
  end
  if saturation > 0.5 then
    append_reason(reasons, "saturation")
  end

  if #reasons == 0 then
    return "nominal"
  end
  return table.concat(reasons, "; ")
end

local function effective_mix_mode(fb_ok_now)
  local mode = math.floor(P.MIX_MODE:get() + 0.5)
  if mode < MIX_MODE_OBSERVE then mode = MIX_MODE_OBSERVE end
  if mode > MIX_MODE_CONTROL then mode = MIX_MODE_CONTROL end
  if P.LOG_ONLY:get() < 0.5 and mode == MIX_MODE_OBSERVE then
    mode = MIX_MODE_MIRROR
  end
  if mode == MIX_MODE_CONTROL and P.FB_REQ:get() >= 0.5 and not fb_ok_now then
    if not FB.warned_req then
      gcs:send_text(MAV_SEVERITY_WARNING,
        SCRIPT_NAME .. ": FB_REQ blocks CONTROL (no fold feedback)")
      FB.warned_req = true
    end
    return MIX_MODE_MIRROR
  end
  if fb_ok_now then FB.warned_req = false end
  return mode
end

local function safe_min_for_phase(target, accel_min, blend_min)
  if target < blend_min then return blend_min end
  if target < accel_min then return accel_min end
  return target
end

local function should_abort_for_descent(target, airspeed, climb_rate, descent_sustained, attitude_abort, attitude_danger)
  local thresh = P.DESC_DANG:get()
  local severe = climb_rate < (thresh * DESC_SEVERE_SCALE)
  local blend_min = P.BLEND_MIN:get()
  local in_fw = target < blend_min and airspeed >= P.FW_AS:get()

  if in_fw then
    return severe or (descent_sustained and (attitude_abort or attitude_danger))
  end
  return severe or descent_sustained
end

local function evaluate_transition(theta, target, airspeed, roll_deg, pitch_deg, climb_rate, saturation, flight_mode, descent_sustained, assist_active, as_guard)
  local phase = phase_for_theta(theta)
  local risk = RISK.OK
  local action = ACTION.ALLOW
  local allowed = target
  local accel_min = P.ACCEL_MIN:get()
  local blend_min = P.BLEND_MIN:get()
  local attitude_abort = math.abs(roll_deg) > P.ATT_ABORT:get() or math.abs(pitch_deg) > P.ATT_ABORT:get()
  local attitude_danger = math.abs(roll_deg) > P.ATT_DANG:get() or math.abs(pitch_deg) > P.ATT_DANG:get()
  local fbwa_low_speed = P.GUARD_FBWA:get() > 0.5 and flight_mode == MODE_FBWA and airspeed < P.BLEND_AS:get()
  local descent_abort = should_abort_for_descent(
    target, airspeed, climb_rate, descent_sustained, attitude_abort, attitude_danger
  )

  if as_guard and target >= accel_min and target < 90 and airspeed < P.BLEND_AS:get() then
    risk = RISK.WARN
  end
  if as_guard and target < accel_min and target >= blend_min and airspeed < P.BLEND_AS:get() then
    risk = RISK.DANGER
  end
  if as_guard and target < blend_min and airspeed < P.FW_AS:get() then
    risk = RISK.DANGER
  end
  if attitude_abort or attitude_danger then risk = RISK.DANGER end
  if climb_rate < P.DESC_DANG:get() then risk = RISK.DANGER end
  if saturation > 0.5 then risk = RISK.DANGER end

  if risk == RISK.DANGER and target < accel_min and target >= blend_min then
    action = ACTION.HOLD_THETA
    allowed = accel_min
  end
  if risk == RISK.DANGER and target < blend_min then
    action = ACTION.HOLD_THETA
    allowed = blend_min
  end
  local abort_trigger = attitude_abort or descent_abort or saturation > 0.5
  if risk == RISK.DANGER and target < 90 and abort_trigger then
    if fbwa_low_speed and attitude_abort and not descent_abort and saturation <= 0.5 then
      action = ACTION.HOLD_THETA
      allowed = math.max(target, safe_min_for_phase(target, accel_min, blend_min))
    else
      action = ACTION.ABORT_TO_Q
      allowed = 90
    end
  end

  allowed, action, risk = apply_assist_link(assist_active, target, allowed, action, risk, airspeed)

  return phase, risk, action, allowed, build_guard_reason(
    target, airspeed, roll_deg, pitch_deg, climb_rate, saturation, descent_sustained, assist_active, as_guard
  )
end

local function update()
  local now_ms = millis():tofloat()
  local dt = (now_ms - ST.last_ms) * 0.001
  ST.last_ms = now_ms

  if P.ENABLE:get() < 0.5 then return update, 100 end

  poll_fold_mavlink(now_ms)
  local fb_ok_now = compute_fb_ok(now_ms)
  publish_fold_gcs(now_ms, fb_ok_now)

  if not ST.announced then
    local mix_mode = effective_mix_mode(fb_ok_now)
    local dyn_hint = Motors_dynamic ~= nil and "Motors_dynamic=ok" or "Motors_dynamic=missing"
    gcs:send_text(MAV_SEVERITY_INFO, string.format(
      "%s: running, mix_mode=%d log_only=%s blend=%.2f %s",
      SCRIPT_NAME, mix_mode, tostring(P.LOG_ONLY:get()), P.MIX_BLEND:get(), dyn_hint))
    ST.announced = true
    ST.last_ann_mix = mix_mode
    ST.last_ann_log = P.LOG_ONLY:get()
  end

  local mix_mode_now = effective_mix_mode(fb_ok_now)
  local log_only_now = P.LOG_ONLY:get()
  if mix_mode_now ~= ST.last_ann_mix or math.abs(log_only_now - (ST.last_ann_log or -1)) > 0.01 then
    gcs:send_text(MAV_SEVERITY_INFO, string.format(
      "%s: running, mix_mode=%d log_only=%s blend=%.2f",
      SCRIPT_NAME, mix_mode_now, tostring(log_only_now), P.MIX_BLEND:get()))
    ST.last_ann_mix = mix_mode_now
    ST.last_ann_log = log_only_now
  end

  local fold_chan = math.floor(P.FOLD_CH:get() + 0.5)
  local pwm_fw = P.PWM_FW:get()
  local pwm_q = P.PWM_Q:get()
  local rate_up = P.RATE_UP:get()
  local rate_dn = P.RATE_DN:get()
  local fold_slew = fold_slew_active(mix_mode_now)
  local fold_pwm = read_ap_fold_pwm(fold_chan)

  local flight_mode = get_flight_mode()
  local airspeed = read_airspeed()

  if fold_slew then
    if not ST.fold_cmd_init then
      ST.theta_ol = pwm_to_theta_target(fold_pwm, pwm_fw, pwm_q)
      ST.theta_cmd = ST.theta_ol
      ST.theta_est = fb_ok_now and fold_pct_to_theta(FB.pct) or ST.theta_ol
      if fb_ok_now then ST.theta_ol = ST.theta_est end
      ST.theta_ap_target = ST.theta_cmd
      ST.fold_cmd_init = true
    end
    ST.theta_ap_target = update_ap_fold_target(
      fold_pwm, pwm_fw, pwm_q, flight_mode, airspeed, ST.theta_cmd, ST.theta_ap_target, dt, rate_up, rate_dn
    )
    ST.theta_target = ST.theta_ap_target
  else
    ST.theta_target = pwm_to_theta_target(fold_pwm, pwm_fw, pwm_q)
    ST.theta_ap_target = ST.theta_target
    ST.fold_cmd_init = false
    ST.last_fold_cmd_pwm = nil
  end

  if ST.last_target == nil or math.abs(ST.theta_target - ST.last_target) > 0.5 then
    ST.target_changed_ms = now_ms
    ST.warned_timeout = false
    ST.last_target = ST.theta_target
  end

  if not fold_slew then
    ST.theta_ol = step_theta_estimate(ST.theta_ol, ST.theta_target, dt, rate_up, rate_dn)
    if fb_ok_now then
      ST.theta_est = fold_pct_to_theta(FB.pct)
      ST.theta_ol = ST.theta_est
    else
      ST.theta_est = ST.theta_ol
    end
  end

  local throttle, roll, pitch, yaw = read_control_inputs()
  local gain = clamp(P.OUT_GAIN:get(), 0, 1)

  local roll_deg, pitch_deg = read_attitude_deg()
  local climb_raw = read_climb_rate()
  local alpha = clamp(dt / CLIMB_FILTER_TAU_S, 0, 1)
  if not ST.climb_filt_init then
    ST.climb_filt = climb_raw
    ST.climb_filt_init = true
  else
    ST.climb_filt = ST.climb_filt + alpha * (climb_raw - ST.climb_filt)
  end

  local desc_thresh = P.DESC_DANG:get()
  if ST.climb_filt < desc_thresh then
    if ST.descent_exceed_start_ms == nil then
      ST.descent_exceed_start_ms = now_ms
    end
  else
    ST.descent_exceed_start_ms = nil
  end
  local descent_sustained = ST.descent_exceed_start_ms ~= nil and
    (now_ms - ST.descent_exceed_start_ms) >= (DESC_SUSTAIN_S * 1000)

  local assist_active = read_assist_active(airspeed, flight_mode)
  local factors_pre = interpolate_factors(ST.theta_est)
  local pwm_pre = {}
  for i = 1, 4 do
    pwm_pre[i] = mix_to_pwm(factors_pre[i], throttle, roll, pitch, yaw, gain)
  end
  local motor_pwm = read_motor_pwm_fallback(pwm_pre)
  local saturation = is_saturated(motor_pwm, P.SAT_PWM:get())
  local boot_elapsed_s = (now_ms - ST.boot_ms) * 0.001
  local as_guard = airspeed_guard_active(airspeed)
  local guard_enabled = P.GUARD:get() > 0.5
  if guard_enabled and boot_elapsed_s < BOOT_GUARD_GRACE_S and not as_guard then
    guard_enabled = false
  end

  local phase, risk, action, allowed_theta, guard_reason = evaluate_transition(
    ST.theta_est, ST.theta_target, airspeed, roll_deg, pitch_deg, ST.climb_filt, saturation, flight_mode, descent_sustained, assist_active, as_guard
  )

  local slew_target = ST.theta_target
  if action ~= ACTION.ALLOW and guard_enabled then
    slew_target = allowed_theta
  end
  if fold_slew then
    ST.theta_cmd = step_theta_estimate(ST.theta_cmd, slew_target, dt, rate_up, rate_dn)
    ST.theta_ol = step_theta_estimate(ST.theta_ol, slew_target, dt, rate_up, rate_dn)
    if fb_ok_now then
      ST.theta_est = fold_pct_to_theta(FB.pct)
      ST.theta_ol = ST.theta_est
    else
      ST.theta_est = ST.theta_ol
    end
  end

  local factors = interpolate_factors(ST.theta_est)
  local pwm = {}
  for i = 1, 4 do pwm[i] = mix_to_pwm(factors[i], throttle, roll, pitch, yaw, gain) end

  local fold_cmd_pwm = fold_pwm or 0
  if fold_slew then
    local fold_timeout = math.max(FOLD_OVERRIDE_MS, math.floor(P.GUARD_MS:get() + 0.5))
    fold_cmd_pwm = apply_fold_servo_output(fold_chan, ST.theta_cmd, pwm_fw, pwm_q, fold_timeout)
  end

  logger:write("TWNG", "Targ,Est,Fold,M1,M2,M3,M4,A1,A2,A3,A4", "fffffffffff",
    ST.theta_target, ST.theta_est, fold_cmd_pwm,
    pwm[1], pwm[2], pwm[3], pwm[4],
    motor_pwm[1], motor_pwm[2], motor_pwm[3], motor_pwm[4])

  local fb_src = fb_ok_now and 1 or 0
  logger:write("TWFB", "Pct,Cnt,Flt,Hld,Ok,Src", "ffffff",
    FB.pct, FB.cnt, FB.flt, FB.hld, fb_ok_now and 1 or 0, fb_src)

  logger:write("TWTR", "Targ,Est,Allow,Phase,Risk,AS,Roll,Pitch,Climb,Sat,Act", "fffffffffff",
    ST.theta_target, ST.theta_est, allowed_theta, phase, risk, airspeed, roll_deg, pitch_deg, ST.climb_filt, saturation, action)

  local mix_theta = ST.theta_est
  if mix_mode_now == MIX_MODE_CONTROL then
    if not fold_slew and action ~= ACTION.ALLOW and guard_enabled then
      mix_theta = allowed_theta
    end
    mix_theta = mix_theta_for_assist(mix_theta, assist_active, airspeed)
  end

  logger:write("TWAS", "Act,Hold,MixT,AsSpd", "ffff",
    assist_active and 1 or 0, allowed_theta, mix_theta, get_param_value("Q_ASSIST_SPEED", 0))

  if action ~= ACTION.ALLOW and guard_enabled then
    if not fold_slew then
      local safe_pwm = theta_to_pwm(allowed_theta, pwm_fw, pwm_q)
      local guard_ms = math.max(100, math.floor(P.GUARD_MS:get() + 0.5))
      SRV_Channels:set_output_pwm_chan_timeout(fold_chan, safe_pwm, guard_ms)
    end
    if action == ACTION.ABORT_TO_Q and vehicle ~= nil then
      pcall(function() vehicle:set_mode(17) end)
    end
    if not ST.warned_guard or guard_reason_key(ST.last_guard_reason) ~= guard_reason_key(guard_reason) then
      gcs:send_text(MAV_SEVERITY_WARNING,
        string.format("%s: guard reason=%s", SCRIPT_NAME, guard_reason))
      ST.warned_guard = true
      ST.last_guard_reason = guard_reason
    end
  else
    ST.warned_guard = false
    ST.last_guard_reason = nil
  end

  local mix_mode = mix_mode_now
  if mix_mode == MIX_MODE_MIRROR then
    for i = 1, 4 do
      -- Function IDs 94-97 are Scripting1-Scripting4 diagnostic outputs (mirror mode only).
      SRV_Channels:set_output_pwm(93 + i, pwm[i])
    end
  elseif mix_mode == MIX_MODE_CONTROL then
    local dyn_factors = interpolate_factors(mix_theta)
    if apply_dynamic_motor_mix(dyn_factors) then
      ST.motors_dynamic_active = true
    else
      ST.motors_dynamic_active = false
      warn_missing_motors_dynamic()
      if can_takeover_motors(mix_mode, action, flight_mode, ST.theta_target, ST.theta_est, fb_ok_now) then
        local blend = clamp(P.MIX_BLEND:get(), 0, 1)
        for i = 1, 4 do
          local blended = math.floor(lerp(pwm[i], motor_pwm[i], blend) + 0.5)
          SRV_Channels:set_output_pwm_chan_timeout(i - 1, blended, 200)
        end
      end
    end
  else
    ST.motors_dynamic_active = false
  end

  if math.abs(ST.theta_target - ST.theta_est) > 2 and (now_ms - ST.target_changed_ms) > P.TIMEOUT:get() * 1000 then
    if not ST.warned_timeout then
      gcs:send_text(MAV_SEVERITY_WARNING, SCRIPT_NAME .. ": fold estimate timeout")
      ST.warned_timeout = true
    end
  end

  local loop_ms = 100
  if mix_mode_now == MIX_MODE_CONTROL and ST.motors_dynamic_active then
    loop_ms = 50
  end
  return update, loop_ms
end

gcs:send_text(MAV_SEVERITY_INFO, SCRIPT_NAME .. ": loaded")
return update()
